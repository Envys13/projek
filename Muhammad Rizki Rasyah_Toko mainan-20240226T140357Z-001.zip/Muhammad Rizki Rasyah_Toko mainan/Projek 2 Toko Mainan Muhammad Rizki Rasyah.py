from tkinter import *
from tkinter import messagebox

# data login untuk validasi
username = "Rizki"
username2 = "Telkom"
username3 = "Kayko"
password = "12345"
password2 = "12345"
password3 = "12345"

# fungsi untuk validasi login
def login():
    if username_entry.get() == username and password_entry.get() == password:
        messagebox.showinfo("Berhasil", "Login berhasil")
        # jika login berhasil, buka halaman utama aplikasi
        main_window()
    elif username_entry.get() == username2 and password_entry.get() == password2:
        messagebox.showinfo("Berhasil", "Login berhasil")
        # jika login berhasil, buka halaman utama aplikasi
        main_window()
    elif username_entry.get() == username3 and password_entry.get() == password3:
        messagebox.showinfo("Berhasil", "Login berhasil")
        # jika login berhasil, buka halaman utama aplikasi
        main_window()
    else:
        messagebox.showerror("Gagal", "Username atau password salah")

# fungsi untuk membuka halaman utama aplikasi
def main_window():
    # kosongkan jendela login
    login_window.destroy()
    # tambahkan widget dan fungsinya di sini
    root = Tk()
    root.geometry("700x700")
    root.title("Toko Mainan")
    root.resizable(False,False)

    # variabel untuk menyimpan daftar belanjaan
    daftar_belanja = []

    # fungsi untuk menambahkan item belanjaan ke daftar_belanja
    def tambah_belanja(nama_barang, harga_barang):
        daftar_belanja.append({"nama": nama_barang, "harga": harga_barang})
        belanja_listbox.insert(END, f"{nama_barang} - Rp {harga_barang}")

    # fungsi untuk menghapus item belanjaan dari daftar_belanja
    def hapus_belanja():
        selected_index = belanja_listbox.curselection()
        if selected_index:
            del daftar_belanja[selected_index[0]]
            belanja_listbox.delete(selected_index)

    def buat_struk():
        # buat jendela struk
        struk_window = Tk()
        struk_window.geometry("300x400")
        struk_window.title("Struk Belanjaan")

        # tambahkan label untuk header struk
        header_label = Label(struk_window, text="Toko Mainan")
        header_label.config(font=("Courier", 18, "bold"))
        header_label.pack(pady=10)

        # tambahkan listbox untuk menampilkan daftar belanjaan
        belanja_listbox = Listbox(struk_window, width=30)
        belanja_listbox.pack()

        # tambahkan item belanjaan ke listbox
        for barang in daftar_belanja:
            belanja_listbox.insert(END, f"{barang['nama']} - Rp {barang['harga']}")

        # tambahkan label untuk total harga belanjaan
        total_harga = sum([barang["harga"] for barang in daftar_belanja])
        total_label = Label(struk_window, text=f"Total Harga: Rp {total_harga}")
        total_label.pack(pady=10)
        
        # tambahkan tombol untuk menutup jendela struk
        close_button = Button(struk_window, text="Tutup", command=struk_window.destroy)
        close_button.pack(pady=10)

        # tambahkan tombol untuk membayar
        bayar_button = Button(struk_window, text="bayar", command=bayar_total)
        bayar_button.pack(pady=10)

        struk_window.mainloop()

    def bayar_total():
        # membuat jendela baru untuk pembayaran
        pembayaran = Toplevel(root)
        pembayaran.geometry("400x300")
        pembayaran.title("Pembayaran")

        # menghitung total harga belanjaan
        total_harga = sum([barang["harga"] for barang in daftar_belanja])

        # membuat label untuk menampilkan total harga belanjaan
        label_total = Label(pembayaran, text="Total Harga: Rp {}".format(total_harga), font=("Courier",16),fg='black')
        label_total.pack(pady=20)

        # membuat label untuk meminta input dari pengguna
        label_bayar = Label(pembayaran, text="Bayar: ", font=("Courier",14,),fg='black')
        label_bayar.pack()

        # membuat entry untuk memasukkan jumlah uang yang dibayarkan
        entry_bayar = Entry(pembayaran, font=("Courier New", 14), width=15)
        entry_bayar.pack()

        # membuat tombol untuk melakukan pembayaran
        def bayar():
            # mengambil nilai dari entry_bayar
            bayar = int(entry_bayar.get())
            # menghitung kembalian
            kembalian = bayar - total_harga

            if bayar >= total_harga:
                # menampilkan pesan kembalian kepada pengguna
                messagebox.showinfo("Kembalian", "Kembalian Anda: Rp {}".format(kembalian))
                # menutup jendela pembayaran
                pembayaran.destroy()
                # kosongkan daftar belanjaan
                daftar_belanja.clear()
                belanja_listbox.delete(0, END)

            elif bayar <= total_harga:
                kurang = bayar - total_harga
                messagebox.showerror("Uang Kurang", "Uang yang anda masukkan kurang : Rp {}".format(kurang))

        tombol_bayar = Button(pembayaran, text="Bayar", font=("Courier New", 14), fg='black', command=bayar)
        tombol_bayar.pack()

    # membuat daftar barang
    barang_frame = Frame(root)
    barang_frame.pack(side=LEFT, padx=10, pady=10)
    judul_barang = Label(barang_frame, text="Daftar Barang")
    judul_barang.pack()
    barang1_label = Label(barang_frame, text="Hot Wheels - Rp 35.000")
    barang1_label.pack()
    barang1_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Hot Wheels", 35000))
    barang1_button.pack()
    barang2_label = Label(barang_frame, text="Action Figure - Rp 200.000")
    barang2_label.pack()
    barang2_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Action Figure", 200000))
    barang2_button.pack()
    barang3_label = Label(barang_frame, text="Lego Harry Potter - Rp 50.000")
    barang3_label.pack()
    barang3_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Lego Harry Potter", 50000))
    barang3_button.pack()
    barang4_label = Label(barang_frame, text="Pop it - Rp 20.000")
    barang4_label.pack()
    barang4_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Pop it", 20000))
    barang4_button.pack()
    barang5_label = Label(barang_frame, text="Lato Lato - Rp 15.000")
    barang5_label.pack()
    barang5_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Lato Lato", 15000))
    barang5_button.pack()
    barang6_label = Label(barang_frame, text="Nerf Gun - Rp 500.000")
    barang6_label.pack()
    barang6_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Nerf Gun", 500000))
    barang6_button.pack()
    barang7_label = Label(barang_frame, text="Bola - Rp 20.000")
    barang7_label.pack()
    barang7_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Bola", 20000))
    barang7_button.pack()
    barang8_label = Label(barang_frame, text="Board game - Rp 100.000")
    barang8_label.pack()
    barang8_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Board Game", 100000))
    barang8_button.pack()
    barang9_label = Label(barang_frame, text="Puzzle - Rp 200.000")
    barang9_label.pack()
    barang9_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Puzzle", 200000))
    barang9_button.pack()
    barang10_label = Label(barang_frame, text=" Robot - Rp 250.000")
    barang10_label.pack()
    barang10_button = Button(barang_frame, text="Tambahkan ke keranjang", command=lambda: tambah_belanja("Robot", 250000))
    barang10_button.pack()

    # Tombol Exit
    def exit_program():
        root.destroy()
    tombol_exit = Button(root, text="Exit", font=("Courier New", 12),command=exit_program)
    tombol_exit.pack(side=BOTTOM, padx=0,pady=15)

    # membuat keranjang belanja
    keranjang_frame = Frame(root)
    keranjang_frame.pack(side=LEFT, padx=10, pady=10)
    judul_keranjang = Label(keranjang_frame, text="Keranjang Belanja")
    judul_keranjang.pack()
    belanja_listbox = Listbox(keranjang_frame, width=30)
    belanja_listbox.pack()
    hapus_belanja_button = Button(keranjang_frame, text="Hapus barang", command=hapus_belanja)
    hapus_belanja_button.pack()
    cetak_struk_button = Button(keranjang_frame, text="Cetak Struk", command=buat_struk)
    cetak_struk_button.pack()
    root.mainloop()


# buat jendela login
login_window = Tk()
login_window.geometry("400x300")
login_window.title("Login Toko Mainan")

# tambahkan widget untuk input username dan password
username_label = Label(login_window, text="Username")
username_label.pack()
username_entry = Entry(login_window)
username_entry.pack()
password_label = Label(login_window, text="Password")
password_label.pack()
password_entry = Entry(login_window, show="*")
password_entry.pack()
copyright_label = Label(login_window, text="Copyright By Rizki")
copyright_label.pack(pady=15)

# tambahkan tombol login
login_button = Button(login_window, text="Login", command=login)
login_button.pack()

login_window.mainloop()
